#!/bin/bash
. xsl-fo.sh
/cygdrive/c/Applications/fop/fop.bat -dpi 150 -fo cg3.fo -pdf cg3.pdf
