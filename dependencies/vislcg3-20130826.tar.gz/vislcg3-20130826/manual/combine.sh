#!/bin/bash
xmllint --xinclude manual.xml > manual-combined.xml
