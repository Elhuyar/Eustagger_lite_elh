#!/bin/bash
. combine.sh
xmllint --valid --noout manual-combined.xml
