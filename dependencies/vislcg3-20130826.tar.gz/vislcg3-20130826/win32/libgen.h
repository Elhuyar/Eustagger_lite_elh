#ifndef LIBGEN_H
#define LIBGEN_H

#ifdef __cplusplus
	extern "C" {
#endif

char  *basename(char *);

#ifdef __cplusplus
	}
#endif

#endif
