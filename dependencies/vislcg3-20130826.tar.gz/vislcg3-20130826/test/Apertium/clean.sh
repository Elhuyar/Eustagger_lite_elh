#!/bin/bash
rm -f T*/diff.txt
rm -f T*/output.txt
rm -f T*/stdout.txt
rm -f T*/stderr.txt
rm -f T*/grammar.out.txt
rm -f T*/grammar.bin

