#!/usr/bin/perl -pi

s/\r\n/\n/;
s/\r/\n/;
